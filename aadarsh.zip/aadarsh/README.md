# Iris Flower Classification Project 🌸

## Overview
This project classifies Iris flower species based on sepal and petal measurements using a machine learning model.

## Dataset
- **Source:** UCI Machine Learning Repository
- **Features:** Sepal Length, Sepal Width, Petal Length, Petal Width
- **Target:** Species (Setosa, Versicolor, Virginica)

## Steps Followed
1. **Data Cleaning & Preprocessing**
2. **Exploratory Data Analysis (EDA)**
3. **Model Training & Evaluation**
4. **Deployment using Streamlit**

## How to Run
```sh
pip install -r requirements.txt
streamlit run app.py

video demo
https://drive.google.com/file/d/1qAPRYjW50RK2iSrLiYAifhdndpqcP5fP/view?usp=drive_link